# Updating OcuClaw

**Guide version:** 2026-10-28 (1.0.60)

This is the **stable update** path — for any already-installed OcuClaw user. You
do **not** need to be a beta tester to be here. For the **beta channel** (newer
pre-release builds) or a **rollback** from beta back to stable — beta-Discord
testers only — load `{baseDir}/references/beta.md` instead.

For a first-time install, this is the wrong file — load
`{baseDir}/references/fresh-install.md` instead.

Return to the skill's SKILL.md for the guardrails and router.

The "quick Step 10 message test" referenced below is in
`{baseDir}/references/fresh-install.md`; named failure cases (CASE-D,
HOST-OLD, ESCALATE) are in `{baseDir}/references/troubleshooting.md`; the WRAP
closing note is in `{baseDir}/references/wrap-feedback.md`.

## U1 — Update OcuClaw (already installed and healthy)

**U1 checklist — copy and tick:**
- [ ] Checked installed vs. latest version, told the user
- [ ] Pre-flight: evenAiEnabled/evenAiToken consistent (else CASE-D first)
- [ ] Migration pre-flight: hooks + tool access verified
- [ ] Updated + reload/restart verified (warning given)
- [ ] Verified: new Version + Status: loaded + quick message test

**CHECK / LIST — gather the version landscape and translate for the user:**

```
openclaw plugins inspect ocuclaw
```
Note the `Version:` line (installed version).

```
npm view ocuclaw version
```
Latest stable version.

```
npm view ocuclaw dist-tags
```
Available channels (`latest`, `beta`).

```
npm view ocuclaw versions --json
```
```
npm view ocuclaw time --json
```
Read the tail of those lists yourself and show the user only the most recent few versions with dates — e.g. "you're on 1.2.4 (Apr 3); latest is 1.3.0 (Jun 6)". Do not dump the full list. For what changed, point at the changelog or Discord — npm carries no release notes.

Before calling the setup up to date, compare the actual phone/client and bundle
floors (recovery-routing.md). If installed == latest stable and the pair is
compatible, report that no stable bundle update is needed. If the client needs a
newer bundle than stable supplies, report the distribution mismatch; do not end
as healthy, lower the floor or reset credentials. Offer only an approved obtainable
compatible channel/artifact. If they confirm they're a beta-Discord tester and
want that channel, load `{baseDir}/references/beta.md`. Otherwise preserve the
baseline and report the blocked transition. A tested 1.3.7 migration and an
obtainable phone rollback remain separate proof; do not promise either here.

**Pre-flight:** If the evenAiEnabled probe = 1 and the evenAiToken probe = 0 → run **CASE-D** before proceeding.

Before the first mutation in this entry, give rule 5's warning once because
OpenClaw may reload while applying policy or plugin changes. Do not repeat the
warning for each command.

**Migration pre-flight** — existing installs may predate keys that newer plugin versions need; fix them now so the reload/restart verification below picks everything up (for both reads, "Config path not found" just means unset — the command exits nonzero; record it, it's not a blocker):

1. `openclaw config get plugins.entries.ocuclaw.hooks.allowConversationAccess` — if not `true`, run:
   ```
   openclaw config set plugins.entries.ocuclaw.hooks.allowConversationAccess true --strict-json
   ```
   (A new enough OcuClaw sets this itself the first time it loads without it, so after the update it is usually already `true`. An explicit `false` is the user's choice: ask before changing it. Non-secret but privacy-relevant — OpenClaw only runs a plugin's conversation-lifecycle hooks with this set. For OcuClaw those hooks do end-of-turn housekeeping: settle any glasses-display, device-info, or location call still pending when a turn ends so nothing hangs; apply the Even-AI model preference; and name sessions with a short title distilled from the conversation — that last part reads conversation content; tell the user that's what it's for.)
2. `openclaw config get tools` — this is the root pre-flight clue, and it is
   load-bearing: OcuClaw's tools are exposed by default only while the policy
   leaves plugin tools exposed. Act on the first case that matches: a blocking
   `deny` → STOP and ask the user; a non-empty `allow` lacking
   `"ocuclaw"`/`"group:plugins"` → merge `"ocuclaw"` into it (never set `allow`
   and `alsoAllow` in the same scope); a `profile` other than unset/`full`
   (OpenClaw's quickstart writes `coding`) → that profile hides plugin tools,
   so merge `"ocuclaw"` into `tools.alsoAllow` after the usual checkpoint
   (`openclaw config set tools.alsoAllow '["ocuclaw"]' --strict-json`). A
   leftover `alsoAllow: ["ocuclaw"]` from an older setup is harmless — leave
   it. Apply controller-routing.md's **Capability-first
   controller routing** table after restart; this root check is not the
   effective-session verdict.

No extra restart for these — they take effect at the post-update restart below.

Before updating, follow recovery-routing.md's **Interrupted upgrade, retry and
compatible recovery** checks. An interrupted or failed attempt resumes there;
it does not restart fresh installation.

**Pick the update command by the recorded source.** Read `install.source` in
`openclaw plugins inspect ocuclaw --json`:

- **npm** (`openclaw plugins install ocuclaw`, `npm:ocuclaw`, `npm:ocuclaw@beta`):
  use `openclaw plugins update ocuclaw@latest`. Bare `update ocuclaw` follows
  the recorded spec, so a record pinned to `ocuclaw@1.3.7` says "already at
  1.3.7" and a `beta` record says "up to date" while a newer stable exists.
  `@latest` moves both to the newest stable. A beta tester who wants to stay on
  beta goes to beta.md instead.
- **ClawHub** (`clawhub:ocuclaw`): use bare `openclaw plugins update ocuclaw`.
  It follows ClawHub's stable line. Never add `@latest` here: OpenClaw only
  matches `ocuclaw@latest` against npm records, so that update fails with
  "No tracked plugin".

**DO:**

```
u=(); openclaw plugins update --help 2>&1 | grep -q -- '--accept-capabilities' && u+=(--accept-capabilities)
openclaw plugins update ocuclaw@latest "${u[@]}"    # npm record
openclaw plugins update ocuclaw "${u[@]}"           # ClawHub record
```

Run only the line for the recorded source.

On OpenClaw 2026.9.x the update can need the person's consent: when the new
version adds tools or skills, and on the first update after the host moved from
2026.7.x. Ask once inside this phase's checkpoint, listing OcuClaw's tools and
skills from recovery-routing.md's **Installation consent and recorded source**
as ONE final message that ends with the question (never an interim or
commentary message), and run the command with the probed flag only after a
clear yes. Never answer for the person; if they decline, hand them the plain
`openclaw plugins update ocuclaw@latest` (npm record) or
`openclaw plugins update ocuclaw` (ClawHub record), with no probe and no
`--accept-capabilities`, to run in their own terminal, where OpenClaw asks its
own `y/N` and they answer it. Hosts without the flag
run the plain update. A `requires capability consent … was not
updated` reply is a failed update, not a success.

`update` follows the install's **recorded source**: installs tracked against npm
keep updating from npm — that is fine and fully supported; do NOT migrate a
working install just because the fresh-install lane now uses ClawHub. If the
user *asks* to move to the ClawHub lane, select the approved exact version and
follow recovery-routing.md's **Installation consent and recorded source**
procedure. Preserve relayToken, port and enablement, then compare them after the
swap. A consent refusal is not an advisory and does not permit continuation.
An archive-tracked prepublication test uses the approved hash-identified archive
replacement procedure; it does not establish a public channel upgrade.

Allow OpenClaw's reload planner to act, then run the VERIFY below. If the
gateway is live but still serves the old runtime, request one
`openclaw gateway restart --safe` and repeat VERIFY; do not restart
pre-emptively. Never restart it yourself on Cloudways: any gateway restart
there, including OpenClaw's own gateway tool, restarts the whole container. If
the old version stays live, the user restarts from the Cloudways dashboard
(cloudways.md, **Restart and reload on this host**).

**VERIFY:** `openclaw plugins inspect ocuclaw --runtime` shows the new `Version:` and `Status: loaded` (the `--runtime` flag confirms live runtime registration, not just registry state). Report the guide and observed plugin versions, then apply controller-routing.md's **Capability-first controller routing** table. Run a controller `verify` only when the selected lane says that surface exists; an older loaded plugin stays on the standalone version lane. Run a quick Step 10 message test. On success → load `{baseDir}/references/wrap-feedback.md` and deliver the **WRAP** closing note.

**If failed:** CASE-D if validation rejected the update; HOST-OLD if OpenClaw is too old for the new version; the app still reporting "plugin mismatch / update required" while `inspect` shows the new version → PLUGIN-RUNTIME-STALE; otherwise ESCALATE.
